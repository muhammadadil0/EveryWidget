import 'package:flutter/material.dart';
class listView extends StatefulWidget {
  const listView({super.key});

  @override
  State<listView> createState() => _listViewState();
}

class _listViewState extends State<listView> {
  List<String> fruits = ['Banana','Orange','Apple'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('List View'),
      ),
    //  body: ListView.builder(
    //   itemCount: fruits.length,
    //   itemBuilder: (context,index){
    //     return Card(
    //       child: ListTile(
    //         title: Text(fruits[index]),
    //       ),

    //     );
    //   })
    body: GridView.builder(
      
      
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
       itemCount: fruits.length,
       itemBuilder: (context, index){
         return Card(
          child: Center(child: Text(fruits[index])),
         );
       }
      
      
      ),
      
    );
  }
}