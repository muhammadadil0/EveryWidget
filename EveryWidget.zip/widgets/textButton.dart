import 'package:flutter/material.dart';
void main(){
  runApp(new TextButtons());
}
class TextButtons extends StatelessWidget {
  const TextButtons({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         backgroundColor: Colors.blue,
         title: Text('Button'),
      ),
     body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Container(
                 child:  TextButton(
                  style: ButtonStyle(
                    //backgroundColor: WidgetStateProperty.all(Theme.of(context).primaryColor),
                    shape: WidgetStateProperty.all(RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)
                    )),
                    elevation: WidgetStateProperty.all(200),
                    overlayColor: WidgetStateProperty.all(Colors.green),
                    padding: WidgetStateProperty.all(EdgeInsets.all(12)),
                    
                  ),
                  
                  child: Text('Press me',style: TextStyle(
                    fontSize: 19,
                    color: const Color.fromARGB(255, 137, 1, 1),
                    
                    ),),
                  onPressed: (){
                    
                  },
                  
                  
            
                ),
                
                
                
                
            ),
            
          ),
          SizedBox(
            height: 20,
          ),
          Container(
           
            child: ElevatedButton(
              style: ButtonStyle(),
              onPressed: (){
                print('Thanks');
              },
              
              child: Text('Press me')
              ),
          ),
             
        ],
      ),
     ),
     
    );
  }
}