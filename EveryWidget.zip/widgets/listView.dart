import 'package:flutter/material.dart';
class ListGrid extends StatefulWidget {
  const ListGrid({super.key});

  @override
  State<ListGrid> createState() => _ListGridState();
}

class _ListGridState extends State<ListGrid> {
  List<String> fruits = ['Orange','Banana','PineApple'];
  Map fruit_person = {
    'fruits':['Orange','Banana','PineApple'],
    'names':['Arsalan','Adil','Azeem']
  };
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Hello world'),
        elevation: 10,
      ),
      body: Container(
        child: GridView(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
          
           childAspectRatio: 2,
          
          ),
        children:  [
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
         Card(
          child: Center(child: Text('Orange')),
         ),
        ],
        
        
        ),
        
      ),
        
      
    );
  }
}