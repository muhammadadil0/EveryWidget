import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';

// void main() {
//   runApp(AnimatedTextExample());
// }

class AnimatedTextExample extends StatelessWidget {
  const AnimatedTextExample({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.orange,
          title: Text('Animated Text'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Centers the content vertically
            children: [
              AnimatedTextKit(
                animatedTexts: [
                  TypewriterAnimatedText(
                    'Hi, how can I help you?',
                    speed: Duration(milliseconds: 100),
                  ),
                ],
                totalRepeatCount: 4,
                displayFullTextOnTap: true,
                pause: Duration(milliseconds: 200),
                stopPauseOnTap: true,
              ),
              AnimatedTextKit(
                animatedTexts: [
                  RotateAnimatedText('Hello Adil'),
                ]),
                AnimatedTextKit(animatedTexts: 
                [
                  WavyAnimatedText('Hi I am Adil')
                ])
            ],
          ),
        ),
      );
  
  }
}
