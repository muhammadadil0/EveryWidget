import 'package:flutter/material.dart';

class DismissibleExample extends StatefulWidget {
  const DismissibleExample({Key? key}) : super(key: key);

  @override
  _DismissibleExampleState createState() => _DismissibleExampleState();
}

class _DismissibleExampleState extends State<DismissibleExample> {
  List<String> fruits = ['banana', 'Orange', 'Apple'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Dismissible',style: TextStyle(
          color: Colors.white,
        ),),
      ),
      body: ListView.builder(
        itemCount: fruits.length,
        itemBuilder: (context, index) {
          final fruit = fruits[index];
          return Dismissible(
            key: Key(fruit),
            secondaryBackground: Container(
              color: Colors.blueGrey,
            ),
            direction: DismissDirection.startToEnd,
            onDismissed: (direction) {
              if (direction == DismissDirection.startToEnd) {
                // Show a snackbar with the item's name and an undo button
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('$fruit dismissed'),
                    action: SnackBarAction(
                      label: 'Undo',
                      onPressed: () {
                        // Implement undo functionality here by adding the item back to the list
                        setState(() {
                          fruits.insert(index, fruit);
                        });
                      },
                    ),
                  ),
                );
              } else {
                // Show a snackbar with the item's name
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('$fruit dismissed'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
              // Remove the dismissed item from the data source
              setState(() {
                fruits.removeAt(index);
              });
            },
            background: Container(
              color: Colors.blue,
              padding: EdgeInsets.symmetric(horizontal: 20),
              alignment: Alignment.centerLeft,
              child: Icon(Icons.undo),
            ),
            child: Card(
             child:  ListTile(
              title: Text(fruit),
            ),
            )
          );
        },
      ),
    );
  }
}