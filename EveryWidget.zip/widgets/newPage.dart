import 'package:flutter/material.dart';
class PageExample extends StatefulWidget {
  const PageExample({super.key});

  @override
  State<PageExample> createState() => _PageExampleState();
}

class _PageExampleState extends State<PageExample> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Container(
       child: Form(
        child: TextFormField(
          decoration: InputDecoration(),
        )
       
       ),

      ),
    );
  }
}