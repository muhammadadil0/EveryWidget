import 'package:flutter/material.dart';
import 'package:food/widgets/todo_tile.dart';
import 'package:food/widgets/dialogue_box.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final controller = TextEditingController();

  List toDoList = [
    ['Make Tutorial', false],
    ['Do Exercise', false],
  ];

  void CheckBoxChange(bool? value, int index) {
    setState(() {
      toDoList[index][1] = !toDoList[index][1];
    });
  }

  void saveNewTask() {
    setState(() {
      toDoList.add([controller.text, false]);
      controller.clear();
    });
    Navigator.of(context).pop();
  }

  void createNewTask() {
    showDialog(
      context: context,
      builder: (context) {
        return DialogueBox(
          controller: controller,
          onSave: saveNewTask,
          onCancel: () {
            controller.clear();
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow,
      appBar: AppBar(
        title: Text('TO DO'),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 251, 227, 6),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.yellow,
        child: Icon(Icons.add),
        onPressed: createNewTask,
      ),
      body: ListView.builder(
        itemCount: toDoList.length,
        itemBuilder: (context, index) {
          return TodoTile(
            taskName: toDoList[index][0],
            taskComplete: toDoList[index][1],
            onChanged: (value) => CheckBoxChange(value, index),
          );
        },
      ),
    );
  }
}
