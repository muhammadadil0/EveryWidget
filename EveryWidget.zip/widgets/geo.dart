import'package:flutter/material.dart';
class geoLocationWidget extends StatefulWidget {
  const geoLocationWidget({super.key});

  @override
  State<geoLocationWidget> createState() => _geoLocationWidgetState();
}

class _geoLocationWidgetState extends State<geoLocationWidget> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(backgroundColor: Colors.blue,
      title: Center(child: Text('Geo Location')),),
      body: Container(
        child: Column(
          children: [
            ElevatedButton(onPressed: (){}, child: Text("Press me",))
          ],
        ),
      ),
    );
  }
}