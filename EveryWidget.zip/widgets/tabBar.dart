import 'package:flutter/material.dart';
class Tabbarr extends StatelessWidget {
  const Tabbarr({super.key});

  @override
  Widget build(BuildContext context) {
    return  DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.green,
          title: Text("whatsapp"),
          bottom: TabBar(
                labelColor: Colors.white,
            
            indicatorColor: const Color.fromARGB(255, 7, 199, 13),
            tabs: [
            Tab(
              
              icon: Icon(Icons.chat),
              text: " Chat",
              ),
            Tab(
              
              icon: Icon(Icons.camera),
              text: " Camera",
              ),
            Tab(
              
              icon: Icon(Icons.chat),
              text: " Chat",
              ),
          ]),
        ),
        body: TabBarView(children: [
          Container(
            child: Center(child: Text('CHAT')),
          ),
          Container(
            child: Center(child: Text('another')),
          ),
          Container(
            child: Center(child: Text('Camera')),
          ),
        ]),
      ),
      
    );
  }
}