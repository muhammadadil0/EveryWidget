import 'package:flutter/material.dart';

class AlertExample extends StatelessWidget {
  const AlertExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Alert'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            showDialogue(context);
          },
          child: Text('Press me'),
        ),
      ),
    );
  }
}

Future<void> showDialogue(BuildContext context) async {
  return showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('This is an alert Notification'),
        content: SingleChildScrollView(
          child: ListBody(
            children: [
              Text('Alert Notification'),
              Text('Alert Notification'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Notification Approve'),
                  action: SnackBarAction(
                    label: 'Undo',
                    onPressed: () {
                      ScaffoldMessenger.of(context).hideCurrentSnackBar();
                    },
                  ),
                ),
              );
            },
            child: Text('Approve'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('Cancel'),
          ),
        ],
      );
    },
  );
}