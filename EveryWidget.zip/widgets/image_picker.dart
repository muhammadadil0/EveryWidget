import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ImagePickerWidget extends StatefulWidget {
  const ImagePickerWidget({super.key});

  @override
  State<ImagePickerWidget> createState() => _ImagePickerWidgetState();
}

class _ImagePickerWidgetState extends State<ImagePickerWidget> {
  XFile? file;
  List<XFile>? files;
  final ImagePicker _picker = ImagePicker();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Image Picker'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Container(
              height: 300,
              width: double.infinity,
              color: Colors.grey,
              child: Center(
                child: file == null
                    ? Text('Image is not picked')
                    : Image.file(
                        File(file!.path),
                        fit: BoxFit.cover,
                      ),
              ),
            ),
          ),
          ElevatedButton(
            child: Text("Pick Image"),
            onPressed: () async {
              final XFile? photo =
                  await _picker.pickImage(source: ImageSource.gallery);
              setState(() {
                file = photo;
              });
            },
          ),
          Divider(),
          Container(
            child: files == null
                ? Text('Images are not picked')
                : Wrap(
                    children: files!.map((file) {
                      return Image.file(
                        File(file.path),
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      );
                    }).toList(),
                  ),
          ),
          ElevatedButton(
            child: Text("Pick Multiple Images"),
            onPressed: () async {
              final List<XFile>? photos =
                  await _picker.pickMultiImage();
              setState(() {
                files = photos;
              });
            },
          ),
        ],
      ),
    );
  }
}
