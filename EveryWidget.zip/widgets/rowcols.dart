import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class Rowcols extends StatelessWidget {
  const Rowcols({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var w = MediaQuery.of(context).size.width;
    var h = MediaQuery.of(context).size.height;
    return Scaffold(
      // appBar: PreferredSize(
      //   preferredSize: Size.fromHeight(20), // Adjust height as needed
      //   child: AppBar(
      //     backgroundColor: Colors.blue,
      //     shape: RoundedRectangleBorder(
      //       borderRadius: BorderRadius.vertical(
      //         top: Radius.circular(20),
      //         bottom: Radius.circular(20), // Customize this value as needed
      //       ),
      //     ),
      //     title: Container(
      //       margin: EdgeInsets.only(bottom: 10.0), // Adjust margin to move title down
      //       child: Text('Rows and Columns'),
      //     ),
      //   ),
      // ),
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Rows and colums'),
      ),

      body: Container(
        height: h,
        width: w,
        color: Colors.blueGrey,
        child: Center(
          child: Wrap(
            //mainAxisAlignment: MainAxisAlignment.center,
            direction: Axis.vertical,
            alignment: WrapAlignment.end,
            children: [
              
                Container(
            height: 100,
            width: 100,
            color: Colors.yellow,
            child: Center(child: Text('Hello world ')),
          ),
          SizedBox(
            height: 15,
          ),
                Container(
            height: 100,
            width: 100,
            
            color: Colors.black,
            child: Center(child: Text('Hello world ',style:TextStyle(color: Colors.white),)),
          ),
          ],)
        ),
       
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Rowcols(),
    );
  }
}
