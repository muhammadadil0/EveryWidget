import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
void main(){
  runApp(newTextbutton());
}
class newTextbutton extends StatelessWidget {
  const newTextbutton({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text('Button'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Container(
              height: 50,
              width: 100,
              decoration: BoxDecoration(
                      color: Colors.blueAccent,
                      borderRadius: BorderRadius.circular(30),
              ),
              
              child: TextButton(
                style: ButtonStyle(
                  shape: WidgetStateProperty.all(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),

                  )),
                  elevation: WidgetStateProperty.all(10),
                  overlayColor:WidgetStateProperty.all(Colors.green)
                ),
                child: Text('Press me'),
                onPressed: (){},
                ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(
            onPressed: (){
              print('Thanks');
            },
            child: Text('Press me'),
          )
        ],
      ),

    );
  }
}