import 'package:flutter/material.dart';
class Snackbar extends StatelessWidget {
  const Snackbar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('SnackBar'),
      ),
      body: Container(
        child: Center(
          child: ElevatedButton(
            onPressed: (){
              final snackbar = SnackBar(
                action: SnackBarAction(
                  label: 'Undo', 
                  textColor: Colors.black,
                  onPressed: (){}),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                behavior: SnackBarBehavior.floating,
                content: Text('This is a snackBar notification'),
                backgroundColor: Colors.blue,
                duration: const Duration(
                  milliseconds: 3000,
                ),
                );
              ScaffoldMessenger.of(context).showSnackBar(snackbar);
            }, 
            child: Text('Press me')),
        ),
      ),
    );

  }
}