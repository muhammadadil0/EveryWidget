import 'package:flutter/material.dart';
class DrawerWidget extends StatefulWidget {
  const DrawerWidget({super.key});

  @override
  State<DrawerWidget> createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
  child: Container(
    color: Theme.of(context).primaryColor,
    child: ListView(
      children: [
        DrawerHeader(
          padding: EdgeInsets.zero,
          child: Container(
            padding: EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundImage: NetworkImage(
                      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSro7lIYryQTo_yEvpCKsXmE_2VUwS2TFogjQ&s'),
                ),
                SizedBox(height: 10), // Adjust the spacing between CircleAvatar and Text widgets
                Text(
                  'data',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Data',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ),
        // ListTiles and other items in the drawer
        const ListTile(
          leading: Icon(Icons.folder),
          title: Text('My files'),
        ),
        const ListTile(
          leading: Icon(Icons.group),
          title: Text('Shares with me'),
        ),
        const ListTile(
          leading: Icon(Icons.star),
          title: Text('Starred'),
        ),
        ListTile(
          leading: Icon(Icons.delete),
          title: Text('Trash'),
        ),
        ListTile(
          leading: Icon(Icons.upload),
          title: Text('Uploads'),
        ),
        Divider(),
        ListTile(
          leading: Icon(Icons.share),
          title: Text('Share'),
        ),
        ListTile(
          leading: Icon(Icons.logout),
          title: Text('Logout'),
        ),
      ],
    ),
  ),
),

    //   drawer: Drawer(
      
    //  child: Container(
     
    //   color: Theme.of(context).primaryColor,
    //   child: ListView(
    //     children: [
    //       DrawerHeader(
    //          padding: EdgeInsets.zero,
    //         child: Container(
              
    //           padding: EdgeInsets.all(10),
    //           child: Row(
    //             children: [
    //               CircleAvatar(
    //                 radius:40 ,
    //                 backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSro7lIYryQTo_yEvpCKsXmE_2VUwS2TFogjQ&s'),
    //               ),
    //               SizedBox(
    //                 width: 20,
    //               ),
    //               Column(
    //                 mainAxisAlignment: MainAxisAlignment.center,
    //                 crossAxisAlignment: CrossAxisAlignment.start,
    //                 children: [
    //                   Text('data'),
    //                   Text('Data')
    //                 ],
    //               )
    //             ],
    //           ),
    //         )
    //         ),
    //         const ListTile(
    //           leading: Icon(Icons.folder),
    //           title: Text('My files'),
    //         ),
    //         const ListTile(
    //           leading: Icon(Icons.group),
    //           title: Text('Shares with me'),
    //         ),
    //        const  ListTile(
    //           leading: Icon(Icons.star),
    //           title: Text('Starred'),
    //         ),
    //         ListTile(
    //           leading: Icon(Icons.delete),
    //           title: Text('Trash'),
    //         ),
    //         ListTile(
    //           leading: Icon(Icons.upload),
    //           title: Text('Uploads'),
    //         ),
    //         Divider(),
    //          ListTile(
    //           leading: Icon(Icons.share),
    //           title: Text('Share'),
    //         ),
    //          ListTile(
    //           leading: Icon(Icons.logout),
    //           title: Text('Logout'),
    //         ),

    //     ],
    //   ),
    //  ),
     
     
    //   ),
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Drawer'),
      ),
    body: Center(
      child: Container(
        
        child: Text('Hey there'),
      ),
    ),
    );
  }
}