import 'package:flutter/material.dart';

class ExampleLogin extends StatefulWidget {
  const ExampleLogin({Key? key}) : super(key: key);

  @override
  State<ExampleLogin> createState() => _ExampleLoginState();
}

class _ExampleLoginState extends State<ExampleLogin> {
  int selectIndex = 0;
  PageController pageController = PageController();

  String firstName = '';
  String lastName = '';
  String email = '';
  String password = '';
  final _formKey = GlobalKey<FormState>();

  void trySubmit() {
    final isValid = _formKey.currentState!.validate();
    if (isValid) {
      submitForm();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error')),
      );
    }
  }

  void submitForm() {
    _formKey.currentState!.save();
    print('First Name: $firstName');
    print('Last Name: $lastName');
    print('Email: $email');
    // Here you can handle the submission logic, e.g., sending data to an API
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //leading: Icon(Icons.arrow_back_ios_new),
        backgroundColor: Colors.orange,
        title: Text('Login Form'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                decoration: InputDecoration(
                  hintText: "Enter the First Name",
                  labelText: "First Name",
                ),
                key: ValueKey('firstName'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'First Name should not be empty';
                  } else {
                    return null;
                  }
                },
                onSaved: (value) {
                  firstName = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(
                  hintText: "Enter the Last Name",
                  labelText: "Last Name",
                ),
                key: ValueKey('lastName'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Last Name should not be empty';
                  } else {
                    return null;
                  }
                },
                onSaved: (value) {
                  lastName = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(
                  hintText: "Enter the Email",
                  labelText: "Email",
                ),
                key: ValueKey('email'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Email should not be empty';
                  } else {
                    return null;
                  }
                },
                onSaved: (value) {
                  email = value!;
                },
              ),
              TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  hintText: "Enter the Password",
                  labelText: "Password",
                ),
                key: ValueKey('password'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Password should not be empty';
                  } else {
                    return null;
                  }
                },
                onSaved: (value) {
                  password = value!;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: trySubmit,
                child: Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
