import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
class TodoTile extends StatelessWidget {
  final String taskName;
  final bool taskComplete;
  Function(bool?)? onChanged;


   TodoTile({super.key,
  required this.taskName,
  required this.taskComplete,
  required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return  Padding(
      padding: EdgeInsets.only(left: 25.0,right: 25,top: 25),
      child: Container(
        padding: EdgeInsets.all(24),
        child: Row(
          children: [
            Checkbox(
              activeColor: Colors.black,
              value: taskComplete, onChanged: onChanged),
            Text(taskName,
            style: TextStyle(
              decoration: taskComplete? TextDecoration.lineThrough:TextDecoration.none,
            ),),
          ],
        ),
        decoration: BoxDecoration(color: Color.fromARGB(255, 255, 230, 0),
      borderRadius: BorderRadius.circular(12)),
      ),
    );
  }
}