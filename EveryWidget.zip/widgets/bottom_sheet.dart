import 'package:flutter/material.dart';

class BottomSheetExample extends StatelessWidget {
  const BottomSheetExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: Container(
          width: 100,
          height: 100,
          color: Colors.orange,
          child: DrawerHeader(
            child: Column(
              children: [
                
                CircleAvatar(

                )
              ],
            )
            ),
        ),
      ),
      appBar: AppBar(
        
        backgroundColor: Colors.orange,
        title: Text(
          'Bottom Sheet Widget',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            showModalBottomSheet(
              enableDrag: true,
              context: context,
              builder: (context) {
                return Column(
                  mainAxisSize: MainAxisSize.min, // This ensures the bottom sheet takes only necessary space
                  children: [
                    ListTile(
                      title: Text('Orange'),
                      subtitle: Text('Adil'),
                    ),
                    ListTile(
                      title: Text('Water Melon'),
                      subtitle: Text('Kaif'),
                    ),
                    ListTile(
                      title: Text('Banana'),
                      subtitle: Text('Azeem'),
                    ),
                  ],
                );
              },
            );
          },
          child: Text('Press me'),
        ),
      ),
    );
  }
}